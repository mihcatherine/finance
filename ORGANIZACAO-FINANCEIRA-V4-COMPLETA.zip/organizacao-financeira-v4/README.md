# Organização Financeira — V4

Versão focada em:
- logo Espada-de-São-Jorge;
- login/cadastro Appwrite;
- Início com saldo disponível sem investimentos;
- livre para usar incluindo crédito disponível dos cartões;
- cartões com adicionar, editar, excluir, limite, fechamento e vencimento;
- lançamentos Pix/cartão/investimento;
- análise com gráfico de categorias que mais gastam;
- PWA instalável.

## Arquivos na raiz
index.html
app.js
styles.css
manifest.webmanifest
sw.js
logo.svg
icon-192.png
icon-512.png

Os ícones ficam diretamente na raiz. Não existe pasta icons/.
